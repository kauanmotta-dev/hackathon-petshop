import { useState } from 'react';
import type { Page } from '../../types';
import { mockAppointments, mockPets, mockMedicalRecords } from '../../data/mock';
import { ArrowLeftIcon, ClockIcon, CheckIcon, RefreshIcon, FileTextIcon } from '../../components/Icons';
import { Card, StatusBadge, Button, TextArea, Alert } from '../../components/UI';

interface Props { appointmentId: string; onNavigate: (page: Page) => void }

export default function AppointmentDetail({ appointmentId, onNavigate }: Props) {
  const apt = mockAppointments.find(a => a.id === appointmentId);
  const [status, setStatus] = useState(apt?.status || 'AGENDADO');
  const [notes, setNotes] = useState('');
  const [finished, setFinished] = useState(false);

  if (!apt) return (
    <div className="max-w-2xl mx-auto text-center py-20">
      <p className="text-[#536273]">Agendamento não encontrado.</p>
      <Button onClick={() => onNavigate('groomer-dashboard')} variant="tertiary" className="mt-4">Voltar</Button>
    </div>
  );

  const pet = mockPets.find(p => p.id === apt.petId);
  const records = mockMedicalRecords.filter(r => r.petId === apt.petId);

  const start = () => setStatus('EM_ANDAMENTO');
  const finish = () => { setStatus('CONCLUIDO'); setFinished(true); };

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => onNavigate('groomer-dashboard')} className="p-2 rounded-xl hover:bg-[#DDD5CD] text-[#536273] transition-colors">
          <ArrowLeftIcon size={20} />
        </button>
        <div>
          <h1 className="font-display text-xl font-bold text-[#131B24]">Detalhe do atendimento</h1>
          <p className="text-[#536273] text-sm">#{apt.id.toUpperCase()}</p>
        </div>
      </div>

      {finished && (
        <Alert type="success" title="Atendimento finalizado!" message={`Notificação enviada para ${apt.clientName.split(' ')[0]}. O pet está pronto!`} />
      )}

      {/* Pet info */}
      <Card className="p-5">
        <div className="flex items-center gap-4 mb-4">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-2xl flex-shrink-0 shadow"
            style={{ backgroundColor: pet?.color || '#536273' }}
          >
            {pet?.name.charAt(0) || '?'}
          </div>
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <h2 className="font-bold text-[#131B24] text-xl">{pet?.name}</h2>
              <StatusBadge status={status} />
            </div>
            <p className="text-sm text-[#536273]">{pet?.species} · {pet?.breed} · Porte {pet?.size}</p>
            <p className="text-xs text-[#536273] mt-0.5">Tutor: {apt.clientName}</p>
          </div>
        </div>

        {pet?.conditions && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-start gap-2 mb-3">
            <span className="text-amber-600 mt-0.5">⚠</span>
            <div>
              <p className="text-xs font-semibold text-amber-800">Condição especial</p>
              <p className="text-sm text-amber-700">{pet.conditions}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
          {[
            { l: 'Serviço', v: apt.serviceName },
            { l: 'Data', v: new Date(apt.date + 'T12:00').toLocaleDateString('pt-BR') },
            { l: 'Horário', v: apt.time },
          ].map(r => (
            <div key={r.l}>
              <p className="text-xs text-[#536273]">{r.l}</p>
              <p className="font-medium text-[#131B24]">{r.v}</p>
            </div>
          ))}
        </div>

        {apt.notes && (
          <div className="mt-3 pt-3 border-t border-[#DDD5CD]">
            <p className="text-xs text-[#536273] mb-1">Observações do tutor</p>
            <p className="text-sm text-[#131B24] italic">"{apt.notes}"</p>
          </div>
        )}
      </Card>

      {/* Actions */}
      <Card className="p-5">
        <h3 className="font-semibold text-[#131B24] mb-4">Status do atendimento</h3>
        <div className="flex items-center gap-3 mb-5">
          {['AGENDADO', 'EM_ANDAMENTO', 'CONCLUIDO'].map((s, i) => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${status === s || (i === 0 && status !== 'AGENDADO') || (i === 1 && status === 'CONCLUIDO') ? 'bg-[#872B35] text-white' : status === s ? 'bg-[#223143] text-white' : 'bg-[#DDD5CD] text-[#536273]'}`}>
                {(i === 0 && status !== 'AGENDADO') || (i === 1 && status === 'CONCLUIDO') ? <CheckIcon size={14} /> : i + 1}
              </div>
              {i < 2 && <div className={`h-px flex-1 ${status !== 'AGENDADO' && i === 0 ? 'bg-[#872B35]' : status === 'CONCLUIDO' && i === 1 ? 'bg-[#872B35]' : 'bg-[#DDD5CD]'}`} />}
            </div>
          ))}
        </div>

        {status === 'AGENDADO' && (
          <Button onClick={start} size="lg" className="w-full">
            <RefreshIcon size={18} /> Iniciar atendimento
          </Button>
        )}
        {status === 'EM_ANDAMENTO' && (
          <div className="space-y-3">
            <TextArea
              label="Anotações do atendimento (prontuário)"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Observações sobre o pet, comportamento, condições do pelo..."
              rows={3}
            />
            <Button onClick={finish} size="lg" className="w-full bg-green-700 hover:bg-green-800">
              <CheckIcon size={18} /> Finalizar e notificar tutor
            </Button>
          </div>
        )}
        {status === 'CONCLUIDO' && (
          <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl px-4 py-3">
            <CheckIcon size={20} className="text-green-700" />
            <div>
              <p className="font-semibold text-green-800 text-sm">Atendimento finalizado</p>
              <p className="text-xs text-green-700">Notificação enviada ao tutor</p>
            </div>
          </div>
        )}
      </Card>

      {/* Medical records */}
      {records.length > 0 && (
        <Card className="p-5">
          <h3 className="font-semibold text-[#131B24] mb-4 flex items-center gap-2">
            <FileTextIcon size={18} className="text-[#536273]" /> Prontuário de {pet?.name}
          </h3>
          <div className="space-y-3">
            {records.map(r => (
              <div key={r.id} className="border border-[#DDD5CD] rounded-xl p-3">
                <div className="flex items-center gap-2 text-xs text-[#536273] mb-1">
                  <ClockIcon size={12} />
                  <span>{new Date(r.date + 'T12:00').toLocaleDateString('pt-BR')}</span>
                  <span>· {r.service}</span>
                  <span>· por {r.groomer.split(' ')[0]}</span>
                </div>
                <p className="text-sm font-medium text-[#131B24]">{r.notes}</p>
                <p className="text-sm text-[#536273] mt-0.5 leading-relaxed">{r.observations}</p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
