import { useState } from 'react';
import { mockStockItems, mockStockLocations, getStockStatus } from '../../data/mock';
import type { StockItem } from '../../types';
import { PlusIcon, SearchIcon, AlertIcon, CheckIcon, PackageIcon } from '../../components/Icons';
import { Card, StatusBadge, Button, Modal, Input, Select, Alert, StatCard, EmptyState } from '../../components/UI';

export default function Stock() {
  const [items, setItems] = useState(mockStockItems);
  const [search, setSearch] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [movementModal, setMovementModal] = useState<StockItem | null>(null);
  const [addModal, setAddModal] = useState(false);
  const [movType, setMovType] = useState<'ENTRADA' | 'SAIDA'>('ENTRADA');
  const [movQty, setMovQty] = useState('');
  const [movNotes, setMovNotes] = useState('');
  const [success, setSuccess] = useState('');

  const [newItem, setNewItem] = useState<Partial<StockItem>>({});

  const critical = items.filter(i => { const s = getStockStatus(i); return s === 'critico' || s === 'sem_estoque'; });

  const filtered = items.filter(i => {
    const matchSearch = !search || i.name.toLowerCase().includes(search.toLowerCase());
    const matchLoc = !locationFilter || i.locationId === locationFilter;
    const matchSt = !statusFilter || getStockStatus(i) === statusFilter;
    return matchSearch && matchLoc && matchSt;
  });

  const applyMovement = () => {
    if (!movementModal || !movQty) return;
    const qty = parseFloat(movQty);
    setItems(prev => prev.map(i => {
      if (i.id !== movementModal.id) return i;
      const newQty = movType === 'ENTRADA' ? i.quantity + qty : Math.max(0, i.quantity - qty);
      return { ...i, quantity: newQty };
    }));
    setMovementModal(null);
    setMovQty('');
    setMovNotes('');
    setSuccess(`${movType === 'ENTRADA' ? 'Entrada' : 'Saída'} registrada com sucesso!`);
    setTimeout(() => setSuccess(''), 3000);
  };

  const addItem = () => {
    if (!newItem.name || !newItem.locationId || !newItem.unit) return;
    const loc = mockStockLocations.find(l => l.id === newItem.locationId);
    setItems(prev => [...prev, {
      id: 'i' + Date.now(),
      locationId: newItem.locationId!,
      locationName: loc?.name || '',
      name: newItem.name!,
      unit: newItem.unit!,
      quantity: parseFloat(String(newItem.quantity || 0)),
      criticalQty: parseFloat(String(newItem.criticalQty || 0)),
      category: newItem.category || 'Geral',
    }]);
    setAddModal(false);
    setNewItem({});
    setSuccess('Material cadastrado com sucesso!');
    setTimeout(() => setSuccess(''), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#131B24]">Controle de estoque</h1>
          <p className="text-[#536273] mt-1">{items.length} materiais cadastrados</p>
        </div>
        <Button onClick={() => setAddModal(true)} size="sm">
          <PlusIcon size={16} /> Novo material
        </Button>
      </div>

      {success && <Alert type="success" title={success} />}

      <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
        <StatCard label="Total" value={items.length} icon={<PackageIcon size={20} />} />
        <StatCard label="Crítico" value={critical.length} icon={<AlertIcon size={20} />} accent={critical.length > 0 ? 'text-[#872B35]' : ''} />
        <StatCard label="Normal" value={items.filter(i => getStockStatus(i) === 'normal').length} icon={<CheckIcon size={20} />} accent="text-green-700" />
        <StatCard label="Locais" value={mockStockLocations.length} icon={<PackageIcon size={20} />} />
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex gap-3 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <SearchIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#536273]" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar material…"
              className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[#cfc6bc] text-sm focus:outline-none focus:ring-2 focus:ring-[#872B35] bg-white"
            />
          </div>
          <select
            value={locationFilter}
            onChange={e => setLocationFilter(e.target.value)}
            className="px-3 py-2.5 rounded-xl border border-[#cfc6bc] text-sm focus:outline-none focus:ring-2 focus:ring-[#872B35] bg-white text-[#131B24]"
          >
            <option value="">Todos os locais</option>
            {mockStockLocations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-2.5 rounded-xl border border-[#cfc6bc] text-sm focus:outline-none focus:ring-2 focus:ring-[#872B35] bg-white text-[#131B24]"
          >
            <option value="">Todos os status</option>
            <option value="normal">Normal</option>
            <option value="baixo">Baixo</option>
            <option value="critico">Crítico</option>
            <option value="sem_estoque">Sem estoque</option>
          </select>
        </div>
      </Card>

      {/* Table / Cards */}
      <Card>
        {filtered.length === 0 ? (
          <EmptyState icon={<PackageIcon size={40} />} title="Nenhum item encontrado" description="Tente ajustar os filtros de busca." />
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#DDD5CD]">
                    {['Material', 'Local', 'Categoria', 'Quantidade', 'Qt. Crítica', 'Status', 'Ações'].map(h => (
                      <th key={h} className="text-left text-xs font-semibold uppercase tracking-wide text-[#536273] px-4 py-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(item => {
                    const st = getStockStatus(item);
                    return (
                      <tr key={item.id} className={`border-b border-[#DDD5CD] last:border-0 hover:bg-[#DDD5CD]/20 ${st === 'sem_estoque' ? 'bg-[#DDD5CD]/30' : ''}`}>
                        <td className="px-4 py-3 font-medium text-[#131B24]">{item.name}</td>
                        <td className="px-4 py-3 text-[#536273]">{item.locationName}</td>
                        <td className="px-4 py-3 text-[#536273]">{item.category}</td>
                        <td className="px-4 py-3 font-bold text-[#131B24]">{item.quantity} {item.unit}</td>
                        <td className="px-4 py-3 text-[#536273]">{item.criticalQty} {item.unit}</td>
                        <td className="px-4 py-3"><StatusBadge status={st} /></td>
                        <td className="px-4 py-3">
                          <button
                            onClick={() => setMovementModal(item)}
                            className="text-xs font-medium text-[#872B35] hover:underline"
                          >
                            + / − Qtd
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="sm:hidden p-4 space-y-3">
              {filtered.map(item => {
                const st = getStockStatus(item);
                return (
                  <div key={item.id} className="border border-[#DDD5CD] rounded-xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-[#131B24]">{item.name}</p>
                        <p className="text-xs text-[#536273]">{item.locationName} · {item.category}</p>
                      </div>
                      <StatusBadge status={st} />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-2xl font-bold text-[#131B24]">{item.quantity}</span>
                        <span className="text-sm text-[#536273] ml-1">{item.unit}</span>
                        <span className="text-xs text-[#536273] ml-2">(mín: {item.criticalQty})</span>
                      </div>
                      <button
                        onClick={() => setMovementModal(item)}
                        className="text-xs font-semibold bg-[#DDD5CD] text-[#223143] px-3 py-1.5 rounded-lg"
                      >
                        Ajustar qtd
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </Card>

      {/* Movement Modal */}
      <Modal open={!!movementModal} onClose={() => setMovementModal(null)} title={`Movimentação — ${movementModal?.name}`}>
        <div className="space-y-4">
          <div className="flex rounded-xl bg-[#DDD5CD]/50 p-1">
            {(['ENTRADA', 'SAIDA'] as const).map(t => (
              <button
                key={t}
                onClick={() => setMovType(t)}
                className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${movType === t ? 'bg-white shadow text-[#131B24]' : 'text-[#536273]'}`}
              >
                {t === 'ENTRADA' ? '+ Entrada' : '− Saída'}
              </button>
            ))}
          </div>
          {movementModal && (
            <div className="bg-[#DDD5CD]/40 rounded-xl p-3 text-sm">
              <p className="text-[#536273]">Estoque atual: <strong className="text-[#131B24]">{movementModal.quantity} {movementModal.unit}</strong></p>
            </div>
          )}
          <Input
            label="Quantidade"
            type="number"
            value={movQty}
            onChange={e => setMovQty(e.target.value)}
            placeholder="0"
            required
          />
          <Input
            label="Motivo / observação"
            value={movNotes}
            onChange={e => setMovNotes(e.target.value)}
            placeholder="Ex: Reposição semanal"
          />
          <div className="flex gap-3">
            <Button variant="tertiary" onClick={() => setMovementModal(null)} className="flex-1">Cancelar</Button>
            <Button onClick={applyMovement} disabled={!movQty} className="flex-1">Registrar</Button>
          </div>
        </div>
      </Modal>

      {/* Add Item Modal */}
      <Modal open={addModal} onClose={() => setAddModal(false)} title="Cadastrar novo material">
        <div className="space-y-4">
          <Input label="Nome do material" value={newItem.name || ''} onChange={e => setNewItem(n => ({ ...n, name: e.target.value }))} placeholder="Ex: Shampoo Neutro" required />
          <Select label="Local de estoque" value={newItem.locationId || ''} onChange={e => setNewItem(n => ({ ...n, locationId: e.target.value }))} required>
            <option value="">Selecione o local</option>
            {mockStockLocations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
          </Select>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Unidade" value={newItem.unit || ''} onChange={e => setNewItem(n => ({ ...n, unit: e.target.value }))} placeholder="Ex: litros, unidades" required />
            <Input label="Categoria" value={newItem.category || ''} onChange={e => setNewItem(n => ({ ...n, category: e.target.value }))} placeholder="Ex: Higiene" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Quantidade inicial" type="number" value={String(newItem.quantity || '')} onChange={e => setNewItem(n => ({ ...n, quantity: parseFloat(e.target.value) }))} placeholder="0" />
            <Input label="Quantidade crítica" type="number" value={String(newItem.criticalQty || '')} onChange={e => setNewItem(n => ({ ...n, criticalQty: parseFloat(e.target.value) }))} placeholder="0" />
          </div>
          <div className="flex gap-3">
            <Button variant="tertiary" onClick={() => setAddModal(false)} className="flex-1">Cancelar</Button>
            <Button onClick={addItem} className="flex-1">Cadastrar material</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
