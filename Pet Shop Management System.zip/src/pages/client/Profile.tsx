import { useState } from 'react';
import type { User } from '../../types';
import { Input, Button, Alert, Card } from '../../components/UI';

interface Props { user: User }

export default function Profile({ user }: Props) {
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone);
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [saved, setSaved] = useState(false);

  const save = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#131B24]">Meu perfil</h1>
        <p className="text-[#536273] mt-1">Gerencie suas informações pessoais</p>
      </div>

      {saved && <Alert type="success" title="Perfil atualizado com sucesso!" />}

      <Card className="p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-full bg-[#223143] flex items-center justify-center text-white font-bold text-2xl">
            {user.name.charAt(0)}
          </div>
          <div>
            <p className="font-semibold text-[#131B24]">{user.name}</p>
            <p className="text-sm text-[#536273]">{user.email}</p>
            <span className="text-xs bg-[#DDD5CD] text-[#536273] px-2 py-0.5 rounded-full mt-1 inline-block">Cliente</span>
          </div>
        </div>

        <div className="space-y-4">
          <Input label="Nome completo" value={name} onChange={e => setName(e.target.value)} />
          <Input label="E-mail" type="email" value={user.email} disabled />
          <Input label="Telefone" type="tel" value={phone} onChange={e => setPhone(e.target.value)} />
        </div>

        <Button onClick={save} className="mt-5 w-full">Salvar alterações</Button>
      </Card>

      <Card className="p-6">
        <h2 className="font-semibold text-[#131B24] mb-4">Alterar senha</h2>
        <div className="space-y-4">
          <Input label="Senha atual" type="password" value={currentPass} onChange={e => setCurrentPass(e.target.value)} placeholder="••••••••" />
          <Input label="Nova senha" type="password" value={newPass} onChange={e => setNewPass(e.target.value)} placeholder="Mínimo 6 caracteres" />
        </div>
        <Button variant="secondary" onClick={save} className="mt-5 w-full">Alterar senha</Button>
      </Card>
    </div>
  );
}
