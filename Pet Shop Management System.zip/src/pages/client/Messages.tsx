import { useState } from 'react';
import type { User } from '../../types';
import { mockMessages } from '../../data/mock';
import { SendIcon } from '../../components/Icons';

interface Props { user: User }

export default function Messages({ user }: Props) {
  const [messages, setMessages] = useState(mockMessages.filter(m => m.fromId === user.id || m.toId === user.id));
  const [input, setInput] = useState('');

  const send = () => {
    if (!input.trim()) return;
    setMessages(m => [...m, {
      id: 'm' + Date.now(),
      fromId: user.id,
      fromName: user.name,
      toId: 'u5',
      toName: 'Pet Shop Vitallis',
      content: input.trim(),
      timestamp: new Date().toISOString(),
      read: true,
    }]);
    setInput('');
  };

  return (
    <div className="max-w-2xl mx-auto h-[calc(100vh-8rem)] flex flex-col">
      <div className="mb-4">
        <h1 className="font-display text-2xl font-bold text-[#131B24]">Mensagens</h1>
        <p className="text-[#536273] text-sm mt-0.5">Converse diretamente com a equipe Vitallis</p>
      </div>

      <div className="flex-1 bg-white rounded-xl border border-[#DDD5CD] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-3 p-4 border-b border-[#DDD5CD]">
          <div className="w-9 h-9 rounded-full bg-[#223143] flex items-center justify-center">
            <span className="text-white text-sm font-bold">V</span>
          </div>
          <div>
            <p className="font-semibold text-[#131B24] text-sm">Pet Shop Vitallis</p>
            <p className="text-xs text-green-600 flex items-center gap-1"><span className="w-1.5 h-1.5 bg-green-500 rounded-full inline-block" /> Online</p>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-hide">
          {messages.map(m => {
            const isMe = m.fromId === user.id;
            return (
              <div key={m.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xs sm:max-w-sm rounded-2xl px-4 py-2.5 ${isMe ? 'bg-[#223143] text-white rounded-br-md' : 'bg-[#DDD5CD] text-[#131B24] rounded-bl-md'}`}>
                  <p className="text-sm leading-relaxed">{m.content}</p>
                  <p className={`text-xs mt-1 ${isMe ? 'text-white/50' : 'text-[#536273]'}`}>
                    {new Date(m.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Input */}
        <div className="p-3 border-t border-[#DDD5CD]">
          <div className="flex gap-2 items-end">
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder="Escreva uma mensagem…"
              rows={1}
              className="flex-1 resize-none rounded-xl border border-[#cfc6bc] px-3 py-2.5 text-sm text-[#131B24] placeholder:text-[#cfc6bc] focus:outline-none focus:ring-2 focus:ring-[#872B35] max-h-24"
            />
            <button
              onClick={send}
              disabled={!input.trim()}
              className="w-10 h-10 bg-[#872B35] text-white rounded-xl flex items-center justify-center hover:bg-[#6e2029] transition-colors disabled:opacity-40 flex-shrink-0"
            >
              <SendIcon size={17} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
