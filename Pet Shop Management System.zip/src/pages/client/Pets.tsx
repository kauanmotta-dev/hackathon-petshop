import { useState } from 'react';
import type { Page, User, Pet } from '../../types';
import { mockPets, mockMedicalRecords } from '../../data/mock';
import { PawIcon, PlusIcon, EditIcon, FileTextIcon, ClockIcon } from '../../components/Icons';
import { Card, Button, Input, Select, TextArea, Modal, EmptyState } from '../../components/UI';

interface Props { user: User; onNavigate: (page: Page) => void }

const PET_COLORS = ['#C8860A', '#888888', '#F0D080', '#D4A870', '#872B35', '#536273', '#223143'];

export default function Pets({ user }: Props) {
  const [pets, setPets] = useState<Pet[]>(mockPets.filter(p => p.ownerId === user.id));
  const [showAdd, setShowAdd] = useState(false);
  const [showRecords, setShowRecords] = useState<Pet | null>(null);
  const [editPet, setEditPet] = useState<Pet | null>(null);
  const [form, setForm] = useState<Partial<Pet>>({});

  const openAdd = () => { setForm({ ownerId: user.id, color: PET_COLORS[0] }); setEditPet(null); setShowAdd(true); };
  const openEdit = (pet: Pet) => { setForm(pet); setEditPet(pet); setShowAdd(true); };

  const handleSave = () => {
    if (!form.name || !form.species || !form.breed || !form.size) return;
    if (editPet) {
      setPets(p => p.map(x => x.id === editPet.id ? { ...x, ...form } as Pet : x));
    } else {
      const newPet: Pet = { id: 'p' + Date.now(), ownerId: user.id, name: form.name!, species: form.species as Pet['species'], breed: form.breed!, size: form.size as Pet['size'], birthDate: form.birthDate || '', notes: form.notes || '', conditions: form.conditions || '', color: form.color || PET_COLORS[0] };
      setPets(p => [...p, newPet]);
    }
    setShowAdd(false);
  };

  const petRecords = showRecords ? mockMedicalRecords.filter(r => r.petId === showRecords.id) : [];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#131B24]">Meus pets</h1>
          <p className="text-[#536273] mt-1">{pets.length} {pets.length === 1 ? 'pet cadastrado' : 'pets cadastrados'}</p>
        </div>
        <Button onClick={openAdd} size="sm">
          <PlusIcon size={16} /> Adicionar pet
        </Button>
      </div>

      {pets.length === 0 ? (
        <EmptyState
          icon={<PawIcon size={48} />}
          title="Nenhum pet cadastrado"
          description="Adicione seus pets para começar a agendar serviços."
          action={<Button onClick={openAdd}><PlusIcon size={16} /> Adicionar primeiro pet</Button>}
        />
      ) : (
        <div className="space-y-4">
          {pets.map(pet => (
            <Card key={pet.id} className="p-5">
              <div className="flex items-start gap-4">
                <div
                  className="w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0 shadow-sm"
                  style={{ backgroundColor: pet.color }}
                >
                  {pet.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div>
                      <h3 className="font-bold text-[#131B24] text-lg">{pet.name}</h3>
                      <p className="text-[#536273] text-sm">{pet.species} · {pet.breed} · Porte {pet.size}</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowRecords(pet)}
                        className="flex items-center gap-1.5 text-xs font-medium text-[#536273] hover:text-[#223143] bg-[#DDD5CD] px-3 py-1.5 rounded-lg transition-colors"
                      >
                        <FileTextIcon size={13} /> Prontuário
                      </button>
                      <button
                        onClick={() => openEdit(pet)}
                        className="flex items-center gap-1.5 text-xs font-medium text-[#536273] hover:text-[#223143] bg-[#DDD5CD] px-3 py-1.5 rounded-lg transition-colors"
                      >
                        <EditIcon size={13} /> Editar
                      </button>
                    </div>
                  </div>
                  {pet.birthDate && (
                    <p className="text-xs text-[#536273] mt-2">
                      Nascimento: {new Date(pet.birthDate + 'T12:00').toLocaleDateString('pt-BR')}
                    </p>
                  )}
                  {pet.notes && (
                    <p className="text-xs text-[#536273] mt-1 bg-[#DDD5CD]/50 rounded-lg px-3 py-2 mt-2">
                      📝 {pet.notes}
                    </p>
                  )}
                  {pet.conditions && (
                    <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mt-2">
                      ⚠ Condição especial: {pet.conditions}
                    </p>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Pet Modal */}
      <Modal
        open={showAdd}
        onClose={() => setShowAdd(false)}
        title={editPet ? `Editar ${editPet.name}` : 'Adicionar pet'}
      >
        <div className="space-y-4">
          <Input label="Nome do pet" value={form.name || ''} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Ex: Thor" required />
          <div className="grid grid-cols-2 gap-4">
            <Select label="Espécie" value={form.species || ''} onChange={e => setForm(f => ({ ...f, species: e.target.value as Pet['species'] }))} required>
              <option value="">Selecione</option>
              <option>Cão</option>
              <option>Gato</option>
              <option>Outro</option>
            </Select>
            <Select label="Porte" value={form.size || ''} onChange={e => setForm(f => ({ ...f, size: e.target.value as Pet['size'] }))} required>
              <option value="">Selecione</option>
              <option>Pequeno</option>
              <option>Médio</option>
              <option>Grande</option>
              <option>Gigante</option>
            </Select>
          </div>
          <Input label="Raça" value={form.breed || ''} onChange={e => setForm(f => ({ ...f, breed: e.target.value }))} placeholder="Ex: Golden Retriever" required />
          <Input label="Data de nascimento" type="date" value={form.birthDate || ''} onChange={e => setForm(f => ({ ...f, birthDate: e.target.value }))} />
          <TextArea label="Observações" value={form.notes || ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Comportamento, preferências…" />
          <TextArea label="Condições especiais" value={form.conditions || ''} onChange={e => setForm(f => ({ ...f, conditions: e.target.value }))} placeholder="Alergias, restrições, cuidados específicos…" />
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-[#536273] mb-2">Cor do avatar</p>
            <div className="flex gap-2 flex-wrap">
              {PET_COLORS.map(c => (
                <button
                  key={c}
                  onClick={() => setForm(f => ({ ...f, color: c }))}
                  className={`w-8 h-8 rounded-full transition-all ${form.color === c ? 'ring-2 ring-offset-2 ring-[#131B24] scale-110' : ''}`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <Button variant="tertiary" onClick={() => setShowAdd(false)} className="flex-1">Cancelar</Button>
            <Button onClick={handleSave} className="flex-1">Salvar pet</Button>
          </div>
        </div>
      </Modal>

      {/* Medical Records Modal */}
      <Modal open={!!showRecords} onClose={() => setShowRecords(null)} title={`Prontuário — ${showRecords?.name}`} size="lg">
        {petRecords.length === 0 ? (
          <EmptyState icon={<FileTextIcon size={36} />} title="Sem registros ainda" description="O prontuário será preenchido após o primeiro atendimento." />
        ) : (
          <div className="space-y-4">
            {petRecords.map(r => (
              <div key={r.id} className="border border-[#DDD5CD] rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 text-sm">
                    <ClockIcon size={14} className="text-[#536273]" />
                    <span className="text-[#536273]">{new Date(r.date + 'T12:00').toLocaleDateString('pt-BR')}</span>
                    <span className="font-medium text-[#131B24]">· {r.service}</span>
                  </div>
                  <span className="text-xs text-[#536273]">por {r.groomer}</span>
                </div>
                <p className="text-sm text-[#131B24] font-medium">{r.notes}</p>
                {r.observations && (
                  <p className="text-sm text-[#536273] mt-1 leading-relaxed">{r.observations}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
